TIA Group copy v0.1.1.0 - beta
This beta version is customized for Skillet project (FORD_CSAP)
==============


SYNTAX:
TIAGroupCopyCLI.exe ProjectPath GroupName Prefix NumberOfGroups FBaseAddrOffset FDestAddrOffset IDeviceDeviceNoOffset IDeviceIoAddrOffset

Parameters:
1. ProjectPath           = path and name of project (e.g. C:\Projects\MyProject\MyProjects.ap15_1)
2. GroupName             = name of exiting template group in project (e.g. Group_
3. Prefix                = Text to be added in fron of device name (e.g. AGV, so _plc will become AGV01_plc
4. NumberOfGroups        = how many groups do you want to end up with including the template group
5. FBaseAddrOffset       = by what increment should the central FBaseAddr of the PLC be increamented
6. FDestAddrOffset       = by what increment should the type 1 F-Dest Address of each module be increased
                           as well as the lower and uper limit setting of type 1 F-DestAddresses)
7. IDeviceIoAddrOffset   = by what increment should the io address for the iDevice connection to the
                           master PLC be incremented (on the master PLC side)
Example:
TIAGroupCopyCLI.exe  C:\Projects\MyProject\MyProjects.ap15_1  Group_ AGV 60 1 50 1 100